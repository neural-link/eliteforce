// Current version of holomatch game

#define	Q3_VERSION		"ST:V HM v1.20"

// end
